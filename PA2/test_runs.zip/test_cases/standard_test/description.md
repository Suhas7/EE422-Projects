#Standard Test
This tests a standard playthrough of the game.
