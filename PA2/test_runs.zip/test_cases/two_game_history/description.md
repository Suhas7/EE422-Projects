#Two Game with History, TA mode test
This tests playing two games with TA mode on and calling HISTORY
