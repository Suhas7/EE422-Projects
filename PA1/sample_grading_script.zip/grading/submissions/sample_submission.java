package assignment1;
public class SortTools {
	public static boolean isSorted(int[]x, int n){
		return true;
	}

	public static int find(int[] x, int n, int v) {
        return 3;
	}

	public static int[] insertGeneral(int[] x, int n, int v) {
        return null;
    }

	public static int insertInPlace(int[] x, int n, int v){
		return 0;
	}
	public static void insertSort(int[] x, int n){}
}

