/* MULTITHREADING <BookingClient.java>
 * EE422C Project 6 submission by
 * Suhas Raja
 * scr2469
 * 16345
 * Slip days used: <0>
 * Fall 2018
 */

package assignment6;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.lang.Thread;

public class BookingClient {
    private Map<String, Integer> offices;
    private Theater theater;
    private static int custId=1;
    private boolean done=false;
    /*
    * @param office maps box office id to number of customers in line
    * @param theater the theater where the show is playing
    */
    public BookingClient(Map<String, Integer> office, Theater theater) {
      this.offices=office;
      this.theater=theater;
    }
    public static void main(String[] args){
        Theater newTheat = new Theater(3,5,"Ouija");
        Map<String, Integer> officesT= new HashMap<String,Integer>();
        officesT.put("BX1",3);
        officesT.put("BX2",4);
        officesT.put("BX3",3);
        officesT.put("BX4",3);
        officesT.put("BX5",3);
        BookingClient BC = new BookingClient(officesT, newTheat);
        BC.simulate();
    }
    /*
     * Starts the box office simulation by creating (and starting) threads
     * for each box office to sell tickets for the given theater
     *
     * @return list of threads used in the simulation,
     *         should have as many threads as there are box offices
     */
    public List<Thread> simulate() {
        List<Thread> threads = new ArrayList<>();
        for(String boxID:offices.keySet()){
            BoxOffice nextBox = new BoxOffice(boxID,offices.get(boxID));
            Thread newThread = new Thread(nextBox);
            threads.add(newThread);
        }
        for(Thread box: threads){box.start();}
        for(Thread box: threads) {
            try {
                box.join(10000);
            }catch(Exception e){}
        }
        return threads;
    }

    private class BoxOffice implements Runnable{
        private String id;
        private int count;
        public BoxOffice(String id, int custs){
            this.id=id;
            this.count=custs;
        }
        @Override
        public void run() {
            while(count>0) {
                Theater.Ticket nextTick;
                int nextCust;
                synchronized((Integer) custId) {nextCust=custId++;}
                nextTick = theater.printTicket(id, theater.bestAvailableSeat(), nextCust);
                if(nextTick==null){
                    if(!done){
                        done=true;
                        System.out.println("Sorry, we are sold out!");
                    }
                    return;
                }
                count--;
            }
        }
    }
}
