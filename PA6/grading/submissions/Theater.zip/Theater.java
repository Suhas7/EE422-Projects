/* MULTITHREADING <Theater.java>
 * EE422C Project 6 submission by
 * Suhas Raja
 * scr2469
 * 16345
 * Slip days used: <0>
 * Fall 2018
 */

package assignment6;

import java.util.ArrayList;
import java.util.List;

public class Theater {
	private ArrayList<Seat> occupied;
	private int maxRows;
	private int maxRowSeats;
	private String currShow;
	private List<Ticket> tickRecords;

	/*
	 * Represents a seat in the theater
	 * A1, A2, A3, ... B1, B2, B3 ...
	 */
	static class Seat {
		private int rowNum;
		private int seatNum;

		public Seat(int rowNum, int seatNum) {
			this.rowNum = rowNum;
			this.seatNum = seatNum;
		}
		public int getSeatNum() {
			return seatNum;
		}
		public int getRowNum() {
			return rowNum;
		}
		@Override
		public String toString() {
			String result="";
			int tempRowNumber=rowNum+1;
			do {
				tempRowNumber--;
				result= ((char)('A'+tempRowNumber%26)) + result;
				tempRowNumber=tempRowNumber/26;
			} while(tempRowNumber>0);
			result += seatNum;
			return result;
		}
	}

    /*
	 * Represents a ticket purchased by a client
	 */
	static class Ticket {
		private String show;
		private String boxOfficeId;
		private Seat seat;
	  	private int client;
	  	public Ticket(String show, String boxOfficeId, Seat seat, int client) {
			this.show = show;
			this.boxOfficeId = boxOfficeId;
			this.seat = seat;
			this.client = client;
		}
		public Seat getSeat() {
			return seat;
		}
		public String getShow() {
			return show;
		}
		public String getBoxOfficeId() {
			return boxOfficeId;
		}
		public int getClient() {
			return client;
		}
		public static final int ticketStringRowLength = 31;
		public String toString() {
			  String result, dashLine, showLine, boxLine, seatLine, clientLine, eol;
			  eol = System.getProperty("line.separator");
			  dashLine = new String(new char[ticketStringRowLength]).replace('\0', '-');
			  showLine = "| Show: "+show;
			  for(int i=showLine.length(); i<ticketStringRowLength-1; ++i)
				  showLine += " ";
			  showLine += "|";
			  boxLine = "| Box Office ID: "+boxOfficeId;
			  for(int i=boxLine.length(); i<ticketStringRowLength-1; ++i)
				  boxLine += " ";
			  boxLine += "|";
			  seatLine = "| Seat: "+seat.toString();
			  for(int i=seatLine.length(); i<ticketStringRowLength-1; ++i)
				  seatLine+=" ";
			  seatLine+="|";
			  clientLine="| Client: "+client;
			  for(int i=clientLine.length(); i<ticketStringRowLength-1; ++i)
				  clientLine+=" ";
			  clientLine+="|";
			  result = dashLine+eol+showLine + eol +boxLine + eol +
					   seatLine + eol + clientLine + eol + dashLine;
			  return result;
		  }
	}

	public Theater(int numRows, int seatsPerRow, String show) {
		this.maxRows=numRows;
		this.maxRowSeats=seatsPerRow;
		this.currShow=show;
		this.occupied = new ArrayList<Seat>();
	}

	/*
	 * Calculates the best seat not yet reserved
	 *
 	 * @return the best seat or null if theater is full
     */
	public Seat bestAvailableSeat() {
		Seat newSeat;
		if(this.occupied.size()==0){
			newSeat = new Seat(1,1);
			this.occupied.add(newSeat);
			return newSeat;
		}
		Seat lastSeat = this.occupied.get(this.occupied.size()-1);
		int newRow=lastSeat.getRowNum();
		int newCol=lastSeat.getSeatNum();
		if(newRow==maxRowSeats){newRow+=1;newCol=1;}
		else{newCol+=1;}
		if(newRow==maxRows && newCol>maxRowSeats) return null;
		return new Seat(newRow,newCol);
	}

	/*
	 * Prints a ticket for the client after they reserve a seat
     * Also prints the ticket to the console
	 *
     * @param seat a particular seat in the theater
     * @return a ticket or null if a box office failed to reserve the seat
     */
	public Ticket printTicket(String boxOfficeId, Seat seat, int client) {
		if(seat==null) return null;
		Ticket newTick = new Ticket(this.currShow,boxOfficeId,seat,client);
		System.out.print(newTick);
		this.tickRecords.add(newTick);
		return newTick;
	}

	/*
	 * Lists all tickets sold for this theater in order of purchase
	 *
     * @return list of tickets sold
     */
	public List<Ticket> getTransactionLog() {
		return this.tickRecords;
	}
}
