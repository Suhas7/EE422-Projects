/* MULTITHREADING <BookingClient.java>
 * EE422C Project 6 submission by
 * Suhas Raja
 * scr2469
 * 16345
 * Slip days used: <0>
 * Fall 2018
 */

package assignment6;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;
import java.lang.Thread;

public class BookingClient {
    private Map<String, Integer> offices;
    private Theater theater;
    private boolean hasSeats;
    private int custId=1;
    /*
    * @param office maps box office id to number of customers in line
    * @param theater the theater where the show is playing
    */
    public BookingClient(Map<String, Integer> office, Theater theater) {
      this.offices=office;
      this.theater=theater;
    }

    /*
     * Starts the box office simulation by creating (and starting) threads
     * for each box office to sell tickets for the given theater
     *
     * @return list of threads used in the simulation,
     *         should have as many threads as there are box offices
     */
    public List<Thread> simulate() {
        //TODO: Implement this method
        List<Thread> threads = new ArrayList<>();
        for(String boxID:offices.keySet()){
            BoxOffice nextBox = new BoxOffice(boxID,offices.get(boxID));
            Thread newThread = new Thread(nextBox);
            threads.add(newThread);
        }
        for(Thread box: threads){box.start();}
        return null;
    }

    private class BoxOffice implements Runnable{
        private String id;
        private int count;

        public BoxOffice(String id, int custs){
            this.id=id;
            this.count=custs;
        }
        @Override
        public void run() {
            if(!hasSeats){return;}
            if(offices.get(id)>0) {
                Theater.Ticket nextTick;
                synchronized(theater) {
                    nextTick = theater.printTicket(id, theater.bestAvailableSeat(), custId++);
                }
                if(nextTick==null){
                    hasSeats=false;
                    return;
                }
                System.out.println(nextTick);
                offices.put(id, offices.get(id) - 1);
            }
        }
    }
}
